// server.js
// 메이플스토리 캐릭터 기록검색 백엔드
// 넥슨 오픈 API(https://openapi.nexon.com)를 프록시해서 프론트엔드에 내려줍니다.
// API 키를 프론트엔드에 노출하지 않기 위해 반드시 서버를 거칩니다.

require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const NEXON_API_KEY = process.env.NEXON_API_KEY;
const BASE_URL = 'https://open.api.nexon.com/maplestory/v1';

if (!NEXON_API_KEY) {
  console.warn('⚠️  NEXON_API_KEY가 설정되지 않았습니다. .env 파일을 확인하세요.');
}

app.use(express.static(path.join(__dirname, 'public')));

// 공통 fetch 헬퍼
async function nexonGet(pathname, params) {
  const url = new URL(BASE_URL + pathname);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

  const res = await fetch(url, {
    headers: { 'x-nxopen-api-key': NEXON_API_KEY }
  });

  const body = await res.json();
  if (!res.ok) {
    const err = new Error(body.error?.message || '넥슨 API 오류');
    err.status = res.status;
    err.code = body.error?.name;
    throw err;
  }
  return body;
}

// 닉네임 → ocid → 기본정보 + 능력치 + 인기도를 한번에 묶어서 응답
app.get('/api/character/:name', async (req, res) => {
  const name = req.params.name.trim();
  if (!name) return res.status(400).json({ error: '캐릭터 이름을 입력하세요.' });

  try {
    // 1. 닉네임으로 ocid 조회
    const idResult = await nexonGet('/id', { character_name: name });
    const ocid = idResult.ocid;

    // 2. 기본 정보 / 능력치 / 인기도를 병렬로 조회
    const [basic, stat, popularity] = await Promise.all([
      nexonGet('/character/basic', { ocid }),
      nexonGet('/character/stat', { ocid }),
      nexonGet('/character/popularity', { ocid })
    ]);

    // 전투력은 stat 배열 안에서 이름으로 찾아야 함
    const combatPowerStat = stat.final_stat?.find(s => s.stat_name === '전투력');

    res.json({
      name: basic.character_name,
      world: basic.world_name,
      job: basic.character_class,
      level: basic.character_level,
      guild: basic.character_guild_name || '없음',
      exp_rate: basic.character_exp_rate,
      image: basic.character_image,
      power: combatPowerStat ? combatPowerStat.stat_value : '정보 없음',
      popularity: popularity.popularity
    });
  } catch (err) {
    console.error(err);
    if (err.code === 'OPENAPI00004' || err.status === 400) {
      return res.status(404).json({ error: '해당 닉네임의 캐릭터를 찾을 수 없습니다.' });
    }
    if (err.status === 401 || err.status === 403) {
      return res.status(500).json({ error: 'API 키가 유효하지 않습니다. .env 설정을 확인하세요.' });
    }
    res.status(500).json({ error: '조회 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.' });
  }
});

app.listen(PORT, () => {
  console.log(`서버 실행 중: http://localhost:${PORT}`);
});
