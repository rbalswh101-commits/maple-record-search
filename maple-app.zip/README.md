# 메이플 기록실 (실제 API 연동 버전)

넥슨 오픈 API를 사용해 실제 메이플스토리 캐릭터 정보를 조회하는 웹앱입니다.

## 1. API 키 발급

1. https://openapi.nexon.com 접속 후 로그인 (넥슨 계정)
2. **APPLICATION 등록** → "메이플스토리" API 상품 신청
3. 승인 후 발급되는 키를 복사

> 참고: 넥슨 오픈 API는 개인 개발자도 무료로 신청 가능하지만, 승인까지 시간이 걸릴 수 있고
> 캐릭터 정보는 **최근 1~2일 지연**되어 제공됩니다 (실시간 아님, 넥슨 정책).

## 2. 설치

```bash
npm install
```

## 3. 환경변수 설정

`.env.example` 파일을 `.env` 로 복사하고 발급받은 키를 입력하세요.

```bash
cp .env.example .env
```

```
NEXON_API_KEY=발급받은_키
PORT=3000
```

## 4. 실행

```bash
npm start
```

브라우저에서 http://localhost:3000 접속

## 구조

```
maple-app/
├── server.js          # 백엔드 (넥슨 API 프록시)
├── package.json
├── .env.example
└── public/
    └── index.html      # 프론트엔드
```

## 왜 백엔드가 필요한가요?

넥슨 API 키를 브라우저(프론트엔드) 코드에 직접 넣으면 누구나 개발자 도구로
키를 훔쳐볼 수 있습니다. 그래서 서버(`server.js`)가 중간에서 키를 안전하게
보관하고, 브라우저는 서버에만 요청을 보내는 구조로 만들었습니다.

## 배포하고 싶다면

Vercel, Render, Railway 같은 무료 호스팅 서비스에 올릴 수 있습니다.
배포 시에도 `NEXON_API_KEY`는 코드에 넣지 말고, 각 플랫폼의
**환경변수(Environment Variables) 설정**에 등록하세요.

## 참고: 실제 API 응답 필드는 넥슨 정책에 따라 변경될 수 있습니다

이 코드는 2026년 기준 공개 문서를 기반으로 작성되었습니다.
실제 실행 전 https://openapi.nexon.com/game/maplestory 의 최신 문서에서
엔드포인트/필드명이 바뀌지 않았는지 확인해보시는 걸 권장드려요.
